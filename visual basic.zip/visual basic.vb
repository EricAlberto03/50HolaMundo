vbnet
Module Module1
    Sub Main()
        Console.WriteLine("HI WORLD")
    End Sub 
End Module
