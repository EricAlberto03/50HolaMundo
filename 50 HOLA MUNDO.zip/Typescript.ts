Typescript
console.log('HI WORLD);
