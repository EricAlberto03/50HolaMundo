php
<?php echo 'HI WORLD'; ?>
