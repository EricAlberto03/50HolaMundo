kotlin
fun main(args : Array<String>) {
  println("HI WORLD")
}
