
python
print("HI WORLD")