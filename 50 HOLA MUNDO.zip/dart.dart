void main(){
    print("HI WORLD");
}