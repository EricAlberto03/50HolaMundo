*SQL (PostgreSQL)*
sql
SELECT 'HI WORLD';

