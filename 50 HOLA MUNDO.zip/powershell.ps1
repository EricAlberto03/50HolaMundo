powershell
Write-Host "HI WORLD"