erlang
io:fwrite("HI WORLD\n").
