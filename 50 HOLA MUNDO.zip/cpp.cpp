cpp
#include <iostream>
int main() {
  std::cout << "HI WORLD";
  return 0;
}
