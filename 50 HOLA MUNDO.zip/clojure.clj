clojure
(println "HI W0RLD")
