objectivec
#import <Foundation/Foundation.h>
int main() {
   NSLog(@"HI WORLD");
   return 0;
}
