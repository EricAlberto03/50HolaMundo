javascript
console.log("HI WORLD");
