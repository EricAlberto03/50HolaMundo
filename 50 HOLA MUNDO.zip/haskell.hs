haskell
main = putStrLn "HI WORLD"