perl
print "HI WORLD\n";