scala
object HelloWorld extends App {
  println("HI WORLD")
}