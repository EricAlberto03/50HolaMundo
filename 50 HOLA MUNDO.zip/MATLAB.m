MATLAB
disp('HI WORLD')
