
groovy
println 'HI WORLD'